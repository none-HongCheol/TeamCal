﻿# TEAM CAL(외부용) - 설치 exe 만들기
# 같은 폴더의 TeamCalExternal.ps1 (+ google_client.json / client_secret*.json) 을 담은
# TeamCal-버전.exe 를 Windows 기본 .NET 컴파일러로 만듭니다. 관리자 권한 필요 없음.
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms, System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()
function Say($text, $icon = 'Information') { [System.Windows.Forms.MessageBox]::Show($text, 'TEAM CAL(외부용) exe 만들기', 'OK', $icon) | Out-Null }
function New-AppBitmap([int]$n) {
    $bmp = New-Object System.Drawing.Bitmap $n, $n
    $gr = [System.Drawing.Graphics]::FromImage($bmp)
    $gr.SmoothingMode = 'AntiAlias'
    $gr.FillEllipse((New-Object System.Drawing.SolidBrush ([System.Drawing.ColorTranslator]::FromHtml('#1b1b1d'))), 0, 0, $n, $n)
    $dotW = New-Object System.Drawing.SolidBrush ([System.Drawing.Color]::FromArgb(235, 235, 230))
    $dotA = New-Object System.Drawing.SolidBrush ([System.Drawing.ColorTranslator]::FromHtml('#ff8a4c'))
    $k = $n / 32.0
    for ($r = 0; $r -lt 3; $r++) { for ($c = 0; $c -lt 3; $c++) {
        $b = if ($r -eq 1 -and $c -eq 2) { $dotA } else { $dotW }
        $gr.FillEllipse($b, [float]((7 + $c * 7) * $k), [float]((7 + $r * 7) * $k), [float](5 * $k), [float](5 * $k)) } }
    $gr.Dispose()
    return $bmp
}

try {
    $here = Split-Path -Parent $PSCommandPath
    $ps1  = Join-Path $here 'TeamCalExternal.ps1'
    if (-not (Test-Path -LiteralPath $ps1)) { Say "같은 폴더에 TeamCalExternal.ps1 이 없어요.`nzip 압축을 먼저 풀고, 푼 폴더에서 실행해 주세요." 'Warning'; exit 1 }

    $text = [IO.File]::ReadAllText($ps1, [Text.Encoding]::UTF8)
    $m = [regex]::Match($text, "(?m)^\`$AppVersion\s*=\s*'([0-9.]+)'")
    $ver = if ($m.Success) { $m.Groups[1].Value } else { '1.0.0' }

    $json = @(Get-ChildItem -LiteralPath $here -Filter '*.json' -File -ErrorAction SilentlyContinue |
              Where-Object { $_.Name -eq 'google_client.json' -or $_.Name -like 'client_secret*.json' }) | Select-Object -First 1
    $psB64 = [Convert]::ToBase64String([IO.File]::ReadAllBytes($ps1))
    $jsB64 = if ($json) { [Convert]::ToBase64String([IO.File]::ReadAllBytes($json.FullName)) } else { '' }

    # 아이콘 (점 달력 모양, PNG 를 담은 .ico)
    $ico = Join-Path $env:TEMP 'TeamCalExt_build.ico'
    $bmp = New-AppBitmap 64
    $ms = New-Object IO.MemoryStream; $bmp.Save($ms, [System.Drawing.Imaging.ImageFormat]::Png); $png = $ms.ToArray()
    $fs = [IO.File]::Create($ico); $bw = New-Object IO.BinaryWriter($fs)
    $bw.Write([uint16]0); $bw.Write([uint16]1); $bw.Write([uint16]1)
    $bw.Write([byte]64); $bw.Write([byte]64); $bw.Write([byte]0); $bw.Write([byte]0)
    $bw.Write([uint16]1); $bw.Write([uint16]32); $bw.Write([uint32]$png.Length); $bw.Write([uint32]22); $bw.Write($png); $bw.Close()

    $src = @"
using System;
using System.IO;
using System.Diagnostics;
using System.Windows.Forms;
using System.Reflection;
[assembly: AssemblyTitle("TEAM CAL(외부용) 설치")]
[assembly: AssemblyProduct("TEAM CAL(외부용)")]
[assembly: AssemblyDescription("TEAM CAL(외부용) - 팀 휴가 + 내 일정 데스크톱 위젯 설치")]
[assembly: AssemblyCompany("TeamCal")]
[assembly: AssemblyVersion("$ver")]
[assembly: AssemblyFileVersion("$ver")]
static class TeamCalSetup {
  [STAThread]
  static void Main() {
    try {
      string dir = Path.Combine(Path.GetTempPath(), "TeamCalExt_setup_" + Guid.NewGuid().ToString("N").Substring(0, 8));
      Directory.CreateDirectory(dir);
      string ps = Path.Combine(dir, "TeamCalExternal.ps1");
      File.WriteAllBytes(ps, Convert.FromBase64String(PS));
      if (JSON.Length > 0) File.WriteAllBytes(Path.Combine(dir, "google_client.json"), Convert.FromBase64String(JSON));
      string exe = Path.Combine(Environment.SystemDirectory, @"WindowsPowerShell\v1.0\powershell.exe");
      var psi = new ProcessStartInfo(exe, "-NoProfile -ExecutionPolicy Bypass -STA -WindowStyle Hidden -File \"" + ps + "\" -Setup");
      psi.UseShellExecute = false; psi.CreateNoWindow = true;
      Process.Start(psi);
    } catch (Exception e) {
      MessageBox.Show("설치 파일을 풀지 못했어요.\n\n" + e.Message, "TEAM CAL(외부용) 설치", MessageBoxButtons.OK, MessageBoxIcon.Error);
    }
  }
  const string PS = "$psB64";
  const string JSON = "$jsB64";
}
"@

    $out = Join-Path $here "TeamCalExternal-$ver.exe"
    if (Test-Path -LiteralPath $out) { Remove-Item -LiteralPath $out -Force }
    $prov = New-Object Microsoft.CSharp.CSharpCodeProvider
    $cp = New-Object System.CodeDom.Compiler.CompilerParameters
    $cp.GenerateExecutable = $true
    $cp.OutputAssembly = $out
    $cp.GenerateInMemory = $false
    $cp.TreatWarningsAsErrors = $false
    $cp.CompilerOptions = "/target:winexe /optimize /win32icon:`"$ico`""
    [void]$cp.ReferencedAssemblies.Add('System.dll')
    [void]$cp.ReferencedAssemblies.Add('System.Windows.Forms.dll')
    $res = $prov.CompileAssemblyFromSource($cp, $src)
    Remove-Item -LiteralPath $ico -Force -ErrorAction SilentlyContinue
    if ($res.Errors.HasErrors -or -not (Test-Path -LiteralPath $out)) {
        $errs = ($res.Errors | ForEach-Object { $_.ToString() }) -join "`n"
        Say "exe 를 만들지 못했어요. 이 창을 캡처해서 보내 주세요.`n`n$errs" 'Error'; exit 1
    }
    $note = if ($json) { "`n구글 설정 파일($($json.Name))도 함께 들어 있어요." } else { "`n(구글 설정 파일 없이 만들었어요)" }
    Start-Process explorer.exe -ArgumentList "/select,`"$out`""
    Say "TeamCalExternal-$ver.exe 를 만들었어요.$note`n`n이 exe 하나만 팀원에게 보내면 돼요."
} catch {
    Say "exe 를 만들지 못했어요.`n`n$($_.Exception.Message)" 'Error'
    exit 1
}
